// src/app/store.js

import { configureStore } from '@reduxjs/toolkit';
import todosReducer from '../redux/todosSlice'; // 정의한 To-Do 슬라이스의 리듀서 임포트

// Redux 스토어 설정
export const store = configureStore({
    reducer: {
        // 모든 슬라이스의 리듀서를 여기에 등록합니다.
        // 'todos'는 이 리듀서가 관리할 상태의 키가 됩니다 (state.todos)
        todos: todosReducer,
    },
   
});