// src/features/todos/todosSlice.js

import { createSlice } from '@reduxjs/toolkit';

const initialTodos = [
    {
        id: 1,
        text: "HTML 공부",
        checked: true
    },
    {
        id: 2,
        text: "CSS 공부",
        checked: true
    },
    {
        id: 3,
        text: "JavaScript 공부",
        checked: true
    },
    {
        id: 4,
        text: "React 공부",
    }
];

// todosSlice 생성
const todosSlice = createSlice({
    name: 'todos', // 이 슬라이스의 이름 (액션 타입의 접두어로 사용됨, 예: 'todos/addTodo')
    initialState: initialTodos, // 초기 상태

    // 리듀서 정의: 액션과 상태를 어떻게 변경할지 정의
    reducers: {
        // addTodo: 새로운 To-Do를 추가하는 액션
        // payload는 액션이 전달하는 데이터 (여기서는 text)
        addTodo: {
            reducer(state, action) {
                // Immer가 내부적으로 적용되어 상태를 직접 '변경'하는 것처럼 보여도
                // 실제로는 불변성을 유지하는 새 상태를 생성합니다.
                state.push(action.payload);
            },
            // prepare 함수를 사용하여 액션 객체 생성 로직을 캡슐화합니다.
            // 이렇게 하면 컴포넌트에서 dispatch(addTodo(text))만 호출하면 됩니다.
            prepare(text) {
                return {
                    payload: {
                        id: Date.now(), // 고유한 ID 생성 (실제 앱에서는 더 견고한 ID 생성기 사용 권장)
                        text,
                        checked: false, // 새 To-Do는 기본적으로 미완료 상태
                    },
                };
            },
        },
        // removeTodo: 특정 ID의 To-Do를 삭제하는 액션
        removeTodo(state, action) {
            // filter는 새 배열을 반환하므로 Immer와 잘 작동합니다.
            return state.filter(todo => todo.id !== action.payload);
        },
        // toggleTodo: 특정 ID의 To-Do 'checked' 상태를 토글하는 액션
        toggleTodo(state, action) {
            const todo = state.find(todo => todo.id === action.payload);
            if (todo) {
                todo.checked = !todo.checked; // Immer 덕분에 직접 변경 가능
            }
        },
    },
});

// 액션 생성자들을 내보냅니다. (예: addTodo, removeTodo, toggleTodo)
export const { addTodo, removeTodo, toggleTodo } = todosSlice.actions;

// 리듀서를 내보냅니다. (스토어에 연결할 때 사용)
export default todosSlice.reducer;