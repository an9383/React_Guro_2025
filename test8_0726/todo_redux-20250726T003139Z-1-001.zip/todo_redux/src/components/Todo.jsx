// src/Todo.js

import React from 'react';
// import { useCallback, useRef, useState } from 'react'; // 더 이상 필요 없음

// Redux 훅 임포트
import { useSelector } from 'react-redux'; // 상태를 읽기 위해
// import { useDispatch } from 'react-redux'; // 필요에 따라 직접 디스패치 할 수도 있지만, 여기서는 하위 컴포넌트로 전달

import TodoTemplate from './TodoTemplate';
import TodoInsert from './TodoInsert';
import TodoList from './TodoList';

// 스타일은 변경 없음
const style = {
    marginTop: "10rem",
    marginBottom: "auto",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
};

const Todo = () => {
    // useSelector 훅을 사용하여 Redux 스토어에서 To-Do 상태를 가져옵니다.
    // state.todos는 store.js에서 정의한 reducer 키 이름과 일치해야 합니다.
    const todos = useSelector(state => state.todos);

    // 액션 디스패치 함수들은 이제 TodoInsert와 TodoList에서 직접 useDispatch를 사용하거나
    // props로 전달 (현재 구조 유지) 할 수 있습니다. 여기서는 기존 props 전달 방식을 유지합니다.
    // 이전의 handleInsert, handleDelete, handleOnToggle 함수들은 이제 Redux 액션 디스패치로 대체됩니다.

    return (
        <div style={style}>
            <TodoTemplate>
                {/* TodoInsert와 TodoList는 이제 Redux 액션을 직접 디스패치하도록 수정됩니다. */}
                <TodoInsert />
                <TodoList
                    todos={todos}
                    // handleDelete와 handleOnToggle은 TodoListItem에서 직접 Redux 액션을 디스패치하도록 변경됩니다.
                    // 따라서 여기서는 props로 전달할 필요가 없습니다.
                />
            </TodoTemplate>
        </div>
    );
};

export default Todo;