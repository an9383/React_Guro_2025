// src/TodoListItem.js

import React from 'react';
import { MdCheckBox, MdCheckBoxOutlineBlank, MdRemoveCircleOutline } from 'react-icons/md';
import { useDispatch } from 'react-redux'; // useDispatch 훅 임포트
import { removeTodo, toggleTodo } from '../redux/todosSlice'; // 액션 생성자 임포트

// 스타일은 변경 없음
const listItemStyle = {
    padding: '1rem',
    display: 'flex',
    alignItems: 'center',
};

const checkboxStyle = {
    cursor: 'pointer',
    flex: 1,
    display: 'flex',
    alignItems: 'center',
};

const todoTextStyle = {
    marginLeft: '0.5rem',
    flex: 1,
};

const deleteStyle = {
    display: 'flex',
    alignItems: 'center',
    fontSize: '1.5rem',
    color: '#ff6b6b',
    cursor: 'pointer',
};

// handleDelete, handleOnToggle props 제거
const TodoListItem = ({ todo }) => {
    const { id, text, checked } = todo;
    const dispatch = useDispatch(); // useDispatch 훅 초기화

    return (
        <div style={listItemStyle}>
            {/* 체크박스 영역: 클릭 시 toggleTodo 액션 디스패치 */}
            <div style={checkboxStyle} onClick={() => dispatch(toggleTodo(id))}>
                {/* 체크 상태에 따라 다른 아이콘 표시 및 색상 적용 */}
                {checked ? (
                    <MdCheckBox style={{ fontSize: '1.5rem', color: '#339af0' }} />
                ) : (
                    <MdCheckBoxOutlineBlank style={{ fontSize: '1.5rem', color: '#495057' }} />
                )}
                {/* 할 일 텍스트: 완료 상태에 따라 취소선 및 색상 변경 */}
                <div style={{
                    ...todoTextStyle,
                    textDecoration: checked ? 'line-through' : 'none',
                    color: checked ? '#adb5bd' : '#495057',
                }}>
                    {text}
                </div>
            </div>
            {/* 삭제 버튼 영역: 클릭 시 removeTodo 액션 디스패치 */}
            <div style={deleteStyle} onClick={() => dispatch(removeTodo(id))}>
                <MdRemoveCircleOutline />
            </div>
        </div>
    );
};

// React.memo는 여전히 유용합니다. (todo prop이 변경될 때만 리렌더링)
export default React.memo(TodoListItem);