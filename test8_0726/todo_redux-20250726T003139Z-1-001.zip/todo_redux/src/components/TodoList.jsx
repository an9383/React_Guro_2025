// src/TodoList.js

import React from 'react';
import TodoListItem from './TodoListItem';

// 스타일은 변경 없음
const listStyle = {
    minHeight: '320px',
    maxHeight: '513px',
    overflow: 'auto',
};

// handleDelete, handleOnToggle props 제거
const TodoList = ({ todos }) => {
    return (
        <div style={listStyle}>
            {todos.map(todo => (
                <TodoListItem
                    key={todo.id}
                    todo={todo}
                    // handleDelete와 handleOnToggle은 TodoListItem에서 직접 Redux 액션을 디스패치합니다.
                    // 따라서 이 레벨에서 props로 전달할 필요가 없습니다.
                />
            ))}
        </div>
    );
};

// React.memo는 여전히 유용합니다. (todos prop이 변경될 때만 리렌더링)
export default React.memo(TodoList);