// src/TodoInsert.js

import React, { useCallback, useState } from 'react';
import { MdAdd } from 'react-icons/md';
import { useDispatch } from 'react-redux'; // useDispatch 훅 임포트
import { addTodo } from '../redux/todosSlice'; // addTodo 액션 생성자 임포트

// 스타일은 변경 없음
const formStyle = {
    display: 'flex',
    background: '#495057',
};

const inputStyle = {
    background: 'none',
    outline: 'none',
    border: 'none',
    padding: '0.5rem',
    fontSize: '1.125rem',
    lineHeight: '1.5',
    color: 'white',
    flex: '1',
};

const buttonStyle = {
    outline: 'none',
    border: 'none',
    background: '#868e96',
    color: 'white',
    paddingLeft: '1rem',
    paddingRight: '1rem',
    fontSize: '1.5rem',
    display: 'flex',
    alignItems: 'center',
    cursor: 'pointer',
    transition: '0.1s background ease-in',
};

const initialTodo = {
    todo: '',
};

// handleInsert props 제거
const TodoInsert = () => {
    const [state, setState] = useState(initialTodo);
    const dispatch = useDispatch(); // useDispatch 훅 초기화

    const handleChange = useCallback((e) => {
        setState(prev => ({ ...prev, [e.target.name]: e.target.value }));
    }, []);

    const handleSubmit = useCallback((e) => {
        e.preventDefault();
        if (!state.todo.trim()) {
            return;
        }
        // Redux 액션 디스패치: addTodo 액션 생성자에 텍스트를 전달
        dispatch(addTodo(state.todo));
        setState(initialTodo); // 인풋 초기화
    }, [dispatch, state.todo]); // dispatch는 안정적이므로 보통 생략 가능하나 명시해도 무방. state.todo는 필요.

    return (
        <form style={formStyle} onSubmit={handleSubmit}>
            <input
                style={inputStyle}
                type="text"
                name="todo"
                value={state.todo}
                onChange={handleChange}
                placeholder='할 일을 입력하세요'
            />
            <button style={buttonStyle}>
                <MdAdd />
            </button>
        </form>
    );
};

export default TodoInsert;