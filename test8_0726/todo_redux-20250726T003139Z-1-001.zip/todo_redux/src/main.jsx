// src/main.jsx 또는 src/index.js (사용하는 프로젝트 설정에 따라)

import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App'; // 최상위 App 컴포넌트
import { Provider } from 'react-redux'; // React와 Redux를 연결해주는 Provider
import { store } from './redux/store'; // 생성한 Redux 스토어 임포트

ReactDOM.createRoot(document.getElementById('root')).render(
    <React.StrictMode>
        {/* Provider로 App 컴포넌트를 감싸서 스토어를 앱 전체에 제공 */}
        <Provider store={store}>
            <App />
        </Provider>
    </React.StrictMode>,
);