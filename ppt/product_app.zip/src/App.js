import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import './App.css';
import UserList from './pages/UserList';
import ProductList from './pages/ProductList';

function App() {
    return (
        <Router className="App">
            <div>
                <header>
                    <h1>쇼핑몰</h1>
                    <nav>
                        <ul>
                            <li>
                                <Link to="/users">사용자 목록</Link>
                            </li>
                            <li>
                                <Link to="/products">상품 목록</Link>
                            </li>
                        </ul>
                    </nav>
                </header>
            </div>
            <Routes>
                <Route path="/users" element={<UserList />} />
                <Route path="/products" element={<ProductList />} />
                <Route path="/" element={<div>main</div>} />
            </Routes>
        </Router>
    );
}

export default App;
