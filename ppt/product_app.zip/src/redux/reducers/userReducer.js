const initialState = {
    loading: false,
    users: [],
    error: null,
};

export const userReducer = (state=initialState, action) => {
    switch (action.type) {
        case 'USER_INIT':
            return { ...state, loading: true, error: null };
        case 'USER_SUCCESS':
            return {
                ...state,
                loading: false,
                users: action.payload,
                error: null,
            };
        case 'USER_FAILURE':
            return { ...state, loading: false, users: [], error: action.error };
        default:
            return state;
    }
};
