const initialState = {
    loading: false,
    products: [],
    error: null
}

export const productReducer = (state=initialState, action) => {
    switch(action.type){
        case 'PRODUCT_INIT':
            return {...state, loading: true, error: null}
        case 'PRODUCT_SUCCESS':
            return {...state, loading:false, products: action.payload, error: null}
        case "PRODUCT_FAILURE":
            return {...state, loading:false, products:[], error:action.error}
        default:
            return state
    }
}