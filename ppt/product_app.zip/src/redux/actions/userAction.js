export const fetchUsers = () => async (dispatch) => {
    dispatch({ type: 'USER_INIT' });
    try {
        const response = await fetch('http://localhost:3001/users');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        dispatch({ type: 'USER_SUCCESS', payload: data }); // prev 불필요
    } catch (error) {
        console.error(
            '사용자 데이터를 불러오는 중 오류가 발생했습니다:',
            error
        );
        dispatch({ type: 'USER_FAILURE', error }); // prev 불필요
    }
};