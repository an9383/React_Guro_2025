export const fetchProducts = () => async (dispatch) => {
    dispatch({ type: 'PRODUCT_INIT' });
    try {
        const response = await fetch('http://localhost:3001/products');
        // console.log('response', response);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        dispatch({ type: 'PRODUCT_SUCCESS', payload: data });
    } catch (error) {
        console.error('상품 데이터를 불러오는 중 오류 발생했습니다.', error);
        dispatch({ type: 'PRODUCT_FAILURE', error });
    }
};
