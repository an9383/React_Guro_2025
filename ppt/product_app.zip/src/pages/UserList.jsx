import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {fetchUsers} from '../redux/actions/userAction';


const UserList = () => {
    const dispatch = useDispatch();
    const {loading, users, error} = useSelector((state)=>state.users)

    useEffect(() => {
        dispatch(fetchUsers());
    }, [dispatch]); // apiUrl은 상수이므로 의존성 제외

    return (
        <div>
            <h1>사용자 목록</h1>
            {loading && <p>사용자 데이터 불러오는 중....</p>}
            {error && <p> 에러 발생: {error}</p>}
            {!loading && users.length===0 && <p>사용자 데이터가 없습니다.</p>}
            <ul>
                {users.map((user) => (
                    <li key={user.id}>
                        <strong>{user.name}</strong> ({user.age}세,{' '}
                        {user.city}) - {user.email}
                    </li>
                ))}
            </ul>
        </div>
    );
};
export default UserList;
