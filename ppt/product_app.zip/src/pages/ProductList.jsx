import React, { useEffect, useReducer, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProducts } from '../redux/actions/productAction';

const ProductList = () => {
    const dispatch = useDispatch();
    const { loading, products, error } = useSelector((state) => state.products);
    useEffect(() => {
        dispatch(fetchProducts());
    }, [dispatch]);
    return (
        <div>
            <h1>상품 목록</h1>
            {loading && <p>상품 데이터 불러오는 중....</p>}
            {error && <p> 에러 발생: {error}</p>}
            {!loading && products.length === 0 && <p>상품 터가 없습니다.</p>}
            <ul>
                {products.map((product) => (
                    <li key={product.id}>
                        <strong>{product.name}</strong> ${product.price},(
                        {product.category})
                        {product.inStock ? ' (재고 있음)' : ' (재고 없음)'}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default ProductList;
