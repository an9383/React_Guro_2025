import './App.css'
// import UserList from './components/UserList'
// import UserPost from './components/UserPost';
import ProductList from './components/ProductList';
import ProductPost from './components/ProductPost';

const  App = () => {

 return (
  <>
    {/* <UserPost/>
    <br/>
    <UserList/> */}
    <ProductPost/>
    <ProductList/>

  </>
 )
}

export default App;
