import { useState } from 'react'
import './App.css'
import ChangeColor from './components/ChangeColor'

function App() {


  return (
    <>
      <ChangeColor/>
    </>
  )
}

export default App
