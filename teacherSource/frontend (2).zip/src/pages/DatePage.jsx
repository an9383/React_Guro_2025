import React from 'react'

const DatePage = () => {
  return (
    <div>DatePage</div>
  )
}

export default DatePage