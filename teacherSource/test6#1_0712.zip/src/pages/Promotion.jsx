import React from 'react'

const Promotion = () => {
  return (
    <div>Promotion</div>
  )
}

export default Promotion