import React from 'react'

const Sale = () => {
  return (
    <div>Sale</div>
  )
}

export default Sale